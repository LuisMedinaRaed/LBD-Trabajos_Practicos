# Trabajo Prácticos de Laboratorio de Bases de Datos

En este repositorio se guardan todos los trabajos practicos desarrollados durante el cursado de Laboratorio de Bases de Datos. Materia correspondiente al quinto año de la carrera Ingenieria en Computacion dictada en la UNT.

## Construidos con 🛠️

* [MySQL Workbench](https://www.mysql.com/products/workbench/) - Herramienta de diseño y administración de bases de datos MySQL.

## 👨‍💻 Autor

- Iñaki Fernando Lozano
- Luis Medina Raed